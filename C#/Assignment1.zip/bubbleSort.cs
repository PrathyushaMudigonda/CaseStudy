﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignments
{
    class bubbleSort
    {
        static void Main()
        {
            Console.WriteLine("Enter the no of elements :");
            int noOfInputs = int.Parse(Console.ReadLine());

            int[] arrayOfInputs = new int[noOfInputs];
            Console.WriteLine("Enter elements:");

            for (int arrayElements = 0; arrayElements < noOfInputs; arrayElements++)
            {
                arrayOfInputs[arrayElements] = int.Parse(Console.ReadLine());
            }

            for (int rows = noOfInputs - 2; rows >= 0; rows--)
            {
                for (int cols = 0; cols <= rows; cols++)
                {
                    int temp;

                    if (arrayOfInputs[cols] > arrayOfInputs[cols + 1])
                    {
                        temp = arrayOfInputs[cols];
                        arrayOfInputs[cols] = arrayOfInputs[cols + 1];
                        arrayOfInputs[cols + 1] = temp;
                    }
                }
            }
            Console.WriteLine("Sorted Elements:");
            for (int arrayElements = 0; arrayElements < noOfInputs; arrayElements++)
            {
                Console.WriteLine(arrayOfInputs[arrayElements]);
            }
        }
    }
}
