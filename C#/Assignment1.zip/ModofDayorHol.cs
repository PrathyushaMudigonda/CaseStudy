﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public enum DayofWeek1
    {
        Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
    }
    class ModofDayorHol
    {
        public static void Main()
        {
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            if (number > 0 && number <= 7)
            {

                if (number > 0 && number < 6)
                {
                    if (number == (int)DayofWeek1.Monday ||
                    number == (int)DayofWeek1.Tuesday ||
                    number == (int)DayofWeek1.Wednesday ||
                    number == (int)DayofWeek1.Thursday ||
                    number == (int)DayofWeek1.Friday)
                    {
                        Console.WriteLine("position:" + (number - 1) + " number:" + number);
                    }

                }
                else if (number == (int)DayofWeek.Saturday ||
                    number == (int)DayofWeek.Sunday)
                    Console.WriteLine("position:" + (number - 1) + " number:" + number);

            }
            else
            {
                Console.WriteLine("Enter valid number");
            }
        }

    }
}
