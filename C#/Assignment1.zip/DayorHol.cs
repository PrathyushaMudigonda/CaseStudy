﻿using System;

namespace assignment2
{
    public enum DayofWeek
    {
        Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
    }
    class DayorHol
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            if (number > 0 && number <= 7)
            {

                if (number > 0 && number < 6)
                {
                    if (number == (int)DayofWeek.Monday ||
                    number == (int)DayofWeek.Tuesday ||
                    number == (int)DayofWeek.Wednesday ||
                    number == (int)DayofWeek.Thursday ||
                    number == (int)DayofWeek.Friday)
                        Console.WriteLine("It is a working day");

                }
                else
                    Console.WriteLine("It is not a working day");
            }
            else
            {
                Console.WriteLine("Enter valid number");
            }
        }
    }
}
