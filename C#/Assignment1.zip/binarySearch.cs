﻿using System;

namespace assignments
{
    class binarySearch
    {
        static void Main(string[] args)
        {
         
                Console.WriteLine("Enter the no of elements :");
                int noOfInputs = int.Parse(Console.ReadLine());
                int start = 0;
                int end = noOfInputs - 1;
                int middle = (start + end) / 2;
                int[] arrayOfInputs = new int[noOfInputs];
                Console.WriteLine("Enter elements:");
                for (int i = 0; i < noOfInputs; i++)
                {
                    arrayOfInputs[i] = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("Enter the search element:");
                int searchElement = int.Parse(Console.ReadLine());

                while (start <= end)
                {
                    if (arrayOfInputs[middle] < searchElement)
                    {
                        start = middle + 1;
                    }
                    else if (arrayOfInputs[middle] == searchElement)
                    {
                        Console.WriteLine("Element " + searchElement + " is found at the location of " + (middle + 1));
                        break;
                    }
                    else
                    {
                        end = end - 1;
                    }
                    middle = (start + end) / 2;
                }
                if (start > end)
                    Console.WriteLine("Element " + searchElement + " is not found");

            }
        }

    }
